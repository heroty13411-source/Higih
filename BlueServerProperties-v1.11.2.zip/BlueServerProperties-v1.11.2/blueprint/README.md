Place `blueserverproperties-v1.11.2.blueprint` in `/var/www/pterodactyl`
(use your custom panel path if you changed it during installation)

Run:
blueprint -i blueserverproperties-v1.11.2
